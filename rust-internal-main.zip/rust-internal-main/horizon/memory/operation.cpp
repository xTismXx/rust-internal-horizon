#include "operation.hpp"

namespace horizon::memory
{ } // namespace horizon::memory